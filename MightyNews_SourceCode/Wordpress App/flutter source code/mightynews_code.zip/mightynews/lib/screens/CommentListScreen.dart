import 'package:facebook_audience_network/facebook_audience_network.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:intl/intl.dart';
import 'package:mighty_news/AppLocalizations.dart';
import 'package:mighty_news/components/AdmobComponent.dart';
import 'package:mighty_news/components/AppWidgets.dart';
import 'package:mighty_news/components/FacebookComponent.dart';
import 'package:mighty_news/components/PostCommentDialog.dart';
import 'package:mighty_news/main.dart';
import 'package:mighty_news/models/CommentData.dart';
import 'package:mighty_news/network/RestApis.dart';
import 'package:mighty_news/screens/LoginScreen.dart';
import 'package:mighty_news/utils/AdConfigurationConstants.dart';
import 'package:mighty_news/utils/AdMobUtils.dart';
import 'package:mighty_news/utils/Colors.dart';
import 'package:mighty_news/utils/Common.dart';
import 'package:mighty_news/utils/Constants.dart';
import 'package:nb_utils/nb_utils.dart';

class CommentListScreen extends StatefulWidget {
  static String tag = '/CommentListScreen';
  final int? id;

  CommentListScreen(this.id);

  @override
  CommentListScreenState createState() => CommentListScreenState();
}

class CommentListScreenState extends State<CommentListScreen> {
  RewardedAd? rewardedAd;

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    FacebookAudienceNetwork.init(
      iOSAdvertiserTrackingEnabled: false,
    );
    setDynamicStatusBarColor(milliseconds: 400);

    if (isInterstitialAdsEnable == true) {
      loadAd();
    }

    if (adEnableOnAddComment == true) {
      if (getStringAsync(reward) == facebookAudience) {
        loadRewardAd();
      }
    }
  }

  loadAd() {
    if (getStringAsync(interstitial) == facebookAudience) {
      loadFaceBookInterstitialAd();
    } else {
      loadInterstitialAd();
    }
    showAd();
  }

  loadRewardAd() async {
    await loadFaceBookRewardedVideoAd(onCall: () async {
      mAddComment();
    });
  }

  @override
  void dispose() async {
    myInterstitial!.dispose();
    super.dispose();
  }

  Future<void> mAddComment() async {
    if (appStore.isLoggedIn) {
      bool? res = await showInDialog(context, builder: (context) => PostCommentDialog(widget.id));
      if (res ?? false) {
        setState(() {});
      }
    } else {
      LoginScreen(isNewTask: false).launch(context);
    }
  }

  showAd() {
    if (getStringAsync(interstitial) == facebookAudience) {
      showFacebookInterstitialAd();
    } else {
      showInterstitialAd();
    }
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    var appLocalization = AppLocalizations.of(context);

    Widget getAuthorImage(CommentData data) {
      if (data.author_avatar_urls != null && data.author_avatar_urls!.url.validate().isNotEmpty) {
        return cachedImage(
          data.author_avatar_urls!.url!,
          fit: BoxFit.fill,
          height: 80,
          width: 80,
        ).cornerRadiusWithClipRRect(80);
      } else if (data.author_name.validate().isNotEmpty) {
        return Text(data.author_name!.substring(0, 1).toUpperCase(), style: boldTextStyle(color: Colors.white, size: 22)).center();
      } else {
        return SizedBox();
      }
    }

    return Observer(
      builder: (_) => SafeArea(
        top: !isIos ? true : false,
        child: Scaffold(
          appBar: appBarWidget(
            appLocalization!.translate('Comments'),
            showBack: true,
            color: getAppBarWidgetBackGroundColor(),
            textColor: getAppBarWidgetTextColor(),
            actions: [
              IconButton(
                icon: Icon(Icons.add),
                color: getIntAsync(DASHBOARD_PAGE_VARIANT, defaultValue: defaultDashboardPage) == 1 || appStore.isDarkMode ? Colors.white : Colors.black,
                onPressed: () async {
                  if (adEnableOnAddComment) {
                    if (appStore.isLoggedIn) {
                      if (getStringAsync(reward) == facebookAudience) {
                        FacebookRewardedVideoAd.showRewardedVideoAd();
                      } else {
                        showAdMobRewardedAd(onCall: () async {
                          if (appStore.isLoggedIn) {
                            bool? res = await showInDialog(context, builder: (context) => PostCommentDialog(widget.id));
                            if (res ?? false) {
                              setState(() {});
                            }
                          } else {}
                        });
                      }
                    } else {
                      LoginScreen(isNewTask: false).launch(context);
                    }
                  } else {
                    mAddComment();
                  }
                },
              ),
            ],
          ),
          body: Container(
            height: context.height(),
            width: context.width(),
            child: Stack(
              children: [
                FutureBuilder<List<CommentData>>(
                  future: getCommentList(widget.id),
                  builder: (_, snap) {
                    if (snap.hasData) {
                      if (snap.data!.isNotEmpty) {
                        return Container(
                          margin: EdgeInsets.only(bottom: 50),
                          child: ListView.separated(
                            itemCount: snap.data!.length,
                            padding: EdgeInsets.all(16.0),
                            shrinkWrap: true,
                            separatorBuilder: (_, index) => SizedBox(height: 8),
                            itemBuilder: (_, index) {
                              CommentData data = snap.data![index];
                              return data.isMyComment
                                  ? Dismissible(
                                      background: Align(
                                        alignment: Alignment.centerRight,
                                        child: Container(
                                          height: context.height(),
                                          width: context.width() * 0.30,
                                          color: appStore.isDarkMode ? Theme.of(context).cardColor : colorPrimary,
                                          child: Icon(Icons.delete, color: white).onTap(() {}),
                                        ),
                                      ),
                                      onDismissed: (DismissDirection direction) {
                                        snap.data!.removeAt(index);
                                      },
                                      key: ValueKey(snap.data![index]),
                                      child: Container(
                                        child: Row(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(shape: BoxShape.circle, color: getAppPrimaryColor()),
                                              child: getAuthorImage(data),
                                              padding: EdgeInsets.all(2),
                                            ),
                                            16.width,
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(parseHtmlString(data.author_name.validate().removeAllWhiteSpace()), style: boldTextStyle(size: 18)),
                                                Text(parseHtmlString(data.content!.rendered.validate()), style: primaryTextStyle()),
                                              ],
                                            ).expand(),
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.end,
                                              children: [
                                                Text(appLocalization.translate('swipe_right_to_delete'), style: secondaryTextStyle(size: 8)).visible(data.isMyComment),
                                                8.height,
                                                Text(DateFormat('dd MMM, yyyy  HH:mm').format(DateTime.parse(data.date.validate())), style: secondaryTextStyle(size: 10)),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ).paddingBottom(16),
                                      confirmDismiss: (DismissDirection direction) async {
                                        return showConfirmDialog(
                                          context,
                                          appLocalization.translate('delete_dialog'),
                                          positiveText: appLocalization.translate('yes'),
                                          negativeText: appLocalization.translate('no'),
                                          onAccept: () {
                                            if (getBoolAsync(IS_LOGGED_IN)) {
                                              if (data.isMyComment) {
                                                removeComment(id: data.id);
                                              }
                                            } else {
                                              toast(appLocalization.translate('please_log_in'));
                                            }
                                          },
                                        );
                                      },
                                    )
                                  : Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 40,
                                          height: 40,
                                          decoration: BoxDecoration(shape: BoxShape.circle, color: context.cardColor),
                                          child: getAuthorImage(data),
                                        ),
                                        16.width,
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(parseHtmlString(data.author_name.validate().removeAllWhiteSpace()), style: primaryTextStyle()),
                                            Text(parseHtmlString(data.content!.rendered.validate()), style: secondaryTextStyle()),
                                          ],
                                        ).expand(),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Text(appLocalization.translate('swipe_right_to_delete'), style: secondaryTextStyle(size: 8)).visible(data.isMyComment),
                                            8.height,
                                            Text(DateFormat('dd MMM, yyyy  HH:mm').format(DateTime.parse(data.date.validate())), style: secondaryTextStyle(size: 10)),
                                          ],
                                        ),
                                      ],
                                    );
                            },
                          ),
                        );
                      } else {
                        return noDataWidget(context);
                      }
                    }

                    return snapWidgetHelper(snap);
                  },
                ),
                Loader().visible(appStore.isLoading),
              ],
            ),
          ),
          bottomNavigationBar: isBannerAdsEnable == true?Container(
            height: 60,
            child: getStringAsync(banner) == admob
                ? AdWidget(
                    ad: BannerAd(
                      adUnitId: kReleaseMode ? getBannerAdUnitId()! : BannerAd.testAdUnitId,
                      size: AdSize.banner,
                      request: AdRequest(),
                      listener: BannerAdListener(),
                    )..load(),
                  )
                : FacebookBannerAd(
                    placementId: faceBookBannerPlacementId, //testid
                    bannerSize: BannerSize.STANDARD,
                    listener: (result, value) {
                      print("Banner Ad: $result -->  $value");
                    },
                  ),
          ):SizedBox(),
        ),
      ),
    );
  }
}
