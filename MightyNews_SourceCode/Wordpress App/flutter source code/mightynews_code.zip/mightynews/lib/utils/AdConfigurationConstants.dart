bool isOpenAdEnable = true;
bool isBannerAdsEnable = true;
bool isInterstitialAdsEnable = true;
bool isAdEnableBetweenList = true;

bool adEnableOnBookmark = true;
bool adEnableOnShare = true;
bool adEnableOnPlay = true;
bool adEnableOnAddComment = true;
bool adEnableOnChooseTopic = true;

const AD_MOB_OPEN_AD_ID = "ca-app-pub-8037703403650159/1710755075";
const AD_MOB_BANNER_ID = "ca-app-pub-8037703403650159/3070447519";
const AD_MOB_INTERSTITIAL_ID = "ca-app-pub-8037703403650159/6016175059";
const AD_MOB_REWARD_ID = "ca-app-pub-8037703403650159/5505039161";

const AD_MOB_OPEN_AD_ID_IOS = "ca-app-pub-3940256099942544/5662855259";
const AD_MOB_BANNER_ID_IOS = "ca-app-pub-3940256099942544/2934735716";
const AD_MOB_INTERSTITIAL_ID_IOS = "ca-app-pub-3940256099942544/4411468910";
const AD_MOB_REWARD_ID_IOS = "ca-app-pub-3940256099942544/1712485313";

String faceBookBannerPlacementId = "IMG_16_9_APP_INSTALL#357524132871625_357529512871087";
String faceBookRewardPlacementId = "VID_HD_9_16_39S_APP_INSTALL#YOUR_PLACEMENT_ID";
String faceBookInterstitialPlacementId = "IMG_16_9_APP_INSTALL#357524132871625_357529579537747";

String banner = "banner";
String interstitial = "interstitial";
String reward = "rewarded";
String native = 'native';

String admob = "admob";
String facebookAudience = "Facebook";

String mDisplayBanner = admob;
String mDisplayInterstitial = admob;
String mDisplayReward = admob;
String mDisplayNative = admob;
