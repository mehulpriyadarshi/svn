import 'dart:math';

import 'package:facebook_audience_network/ad/ad_banner.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:mighty_news/components/NewsItemWidget.dart';
import 'package:mighty_news/models/DashboardResponse.dart';
import 'package:mighty_news/screens/NewsDetailScreen.dart';
import 'package:mighty_news/utils/AdConfigurationConstants.dart';
import 'package:nb_utils/nb_utils.dart';

// ignore: must_be_immutable
class NewsListWidget extends StatefulWidget {
  static String tag = '/NewsListWidget';
  List<NewsData>? newsList;
  bool? enableScrolling;
  EdgeInsetsGeometry? padding;

  NewsListWidget(this.newsList, {this.enableScrolling, this.padding});

  @override
  NewsListWidgetState createState() => NewsListWidgetState();
}

class NewsListWidgetState extends State<NewsListWidget> {
  int adIndex = 4;

  @override
  void initState() {
    super.initState();
    init();
  }

  init() async {
    //
  }

  int getItemIndex(int ind) {
    if (ind >= adIndex && isAdEnableBetweenList) {
      return ind - 1;
    }
    return ind;
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListView.builder(
        padding: widget.padding ?? EdgeInsets.all(0),
        itemCount: widget.newsList!.length,
        shrinkWrap: true,
        physics: widget.enableScrolling.validate() ? AlwaysScrollableScrollPhysics() : NeverScrollableScrollPhysics(),
        itemBuilder: (_, index) {

          final random = new Random();
          var i = random.nextInt(widget.newsList!.length);
          if (isAdEnableBetweenList && index == i) {
            if (getStringAsync(native) == admob) {
              return Container(
                child: AdWidget(
                  ad: BannerAd(
                    adUnitId: kReleaseMode ? getStringAsync(AD_MOB_BANNER_ID) : BannerAd.testAdUnitId,
                    size: AdSize.banner,
                    request: AdRequest(),
                    listener: BannerAdListener(),
                  )..load(),
                ),
                height: 70,
                width: context.width(),
                alignment: Alignment.center,
              );
            } else {
              return FacebookBannerAd(
                placementId: faceBookBannerPlacementId, //testid
                bannerSize: BannerSize.STANDARD,
                listener: (result, value) {
                  print("Banner Ad: $result -->  $value");
                },
              );
            }
          } else {
            NewsData item = widget.newsList![index];
            return NewsItemWidget(
              item,
              onTap: () {
                NewsDetailScreen(id: item.iD.toString(), disableAd: false, newsData: item).launch(context);
              },
            );
          }
        },

      ),
    );
  }
}
