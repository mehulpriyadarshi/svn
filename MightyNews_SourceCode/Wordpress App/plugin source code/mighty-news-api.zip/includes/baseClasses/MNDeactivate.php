<?php


namespace Includes\baseClasses;

class MNDeactivate {

	public static function init () {

	}
}