package com.mighty.mighty_news_firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
