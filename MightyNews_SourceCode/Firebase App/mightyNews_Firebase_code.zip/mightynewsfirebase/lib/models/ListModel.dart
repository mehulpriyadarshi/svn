import 'package:flutter/material.dart';

class ListModel {
  String? name;
  Widget? widget;
  Widget? leading;

  ListModel({this.name, this.widget, this.leading});
}
