import 'package:flutter/material.dart';
import 'package:mighty_news_firebase/components/AppWidgets.dart';
import 'package:mighty_news_firebase/models/AudiencePollModel.dart';
import 'package:mighty_news_firebase/screens/user/ViewPollDetailScreen.dart';
import 'package:mighty_news_firebase/services/PollAnswerListService.dart';
import 'package:mighty_news_firebase/utils/Colors.dart';
import 'package:mighty_news_firebase/utils/Common.dart';
import 'package:mighty_news_firebase/utils/Constants.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:paginate_firestore/paginate_firestore.dart';

import '../../main.dart';

class MyPollListScreen extends StatefulWidget {
  static String tag = '/MyPollListScreen';

  @override
  MyPollListScreenState createState() => MyPollListScreenState();
}

class MyPollListScreenState extends State<MyPollListScreen> {
  late PollAnswerListService pollAnswerService;

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    //
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget('my_polls'.translate, color: appStore.isDarkMode ? scaffoldSecondaryDark : Colors.white),
      body: PaginateFirestore(
        itemBuilderType: PaginateBuilderType.listView,
        itemBuilder: ( context, documentSnapshot,index) {
          AudiencePollModel data = AudiencePollModel.fromJson(documentSnapshot[index].data() as Map<String, dynamic>);

          return Container(
            decoration: boxDecorationDefault(color: appStore.isDarkMode ? scaffoldSecondaryDark : Colors.white),
            margin: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                IgnorePointer(
                  ignoring: true,
                  child: Container(
                    width: context.width(),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              data.pollQuestion.validate(),
                              style: boldTextStyle(size: 18),
                            ).paddingSymmetric(vertical: 8, horizontal: 8).expand(),
                            Container(
                              padding: EdgeInsets.only(left: 8, right: 8, top: 4, bottom: 4),
                              margin: EdgeInsets.only(right: 8),
                              decoration: BoxDecoration(
                                color: !data.endAt!.difference(DateTime.now()).isNegative ? Colors.green.withOpacity(0.2) : colorPrimary.withOpacity(0.2),
                                borderRadius: radius(defaultRadius),
                                border: Border.all(color: !data.endAt!.difference(DateTime.now()).isNegative ? Colors.green : colorPrimary),
                              ),
                              child: Text(!data.endAt!.difference(DateTime.now()).isNegative ? 'published'.translate : 'unpublished'.translate,
                                  style: boldTextStyle(size: 12, color: !data.endAt!.difference(DateTime.now()).isNegative ? Colors.green : colorPrimary, letterSpacing: 1.5)),
                            )
                          ],
                        ),
                        Container(
                          width: context.width(),
                          padding: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                          child: Wrap(
                            alignment: WrapAlignment.start,
                            spacing: 8,
                            runSpacing: 8,
                            children: data.pollTagsList!.map((e) {
                              return Text(e.validate(), style: primaryTextStyle(color: Colors.blue, size: 20));
                            }).toList(),
                          ),
                        ),
                        Column(
                          children: data.pollChoiceList!.map((e) {
                            pollAnswerService = PollAnswerListService(pollID: data.id);
                            return Container(
                              width: context.width(),
                              height: 40,
                              decoration: BoxDecoration(border: Border.all(color: Colors.grey, width: 0.5)),
                              child: StreamBuilder<List<UserData>>(
                                stream: pollAnswerService.getAllPollAnswerList(),
                                builder: (context, snap) {
                                  if (snap.hasData) {
                                    return Stack(
                                      children: [
                                        Stack(
                                          children: [
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                child: Text(
                                                  e.validate(),
                                                  overflow: TextOverflow.ellipsis,
                                                  style: primaryTextStyle(),
                                                ).paddingSymmetric(horizontal: 4),
                                              ),
                                            ),
                                            if (getPollPercentage(answerList: snap.data!, answer: e.validate()) / 100.0 != 0.0)
                                              AnimatedContainer(
                                                duration: Duration(milliseconds: 500),
                                                width: (context.width() * (getPollPercentage(answerList: snap.data!, answer: e.validate()) / 100.0)) - 32,
                                                color: Colors.green.withOpacity(0.3),
                                              )
                                          ],
                                        ),
                                        Align(
                                          alignment: Alignment.centerRight,
                                          child: Container(
                                            child: Text(
                                              '${getPollPercentage(answerList: snap.data!, answer: e.validate()).roundToDouble()} %',
                                              style: boldTextStyle(),
                                              overflow: TextOverflow.ellipsis,
                                            ).paddingSymmetric(horizontal: 4),
                                          ),
                                        ),
                                      ],
                                    );
                                  }
                                  return Container();
                                },
                              ),
                            ).paddingSymmetric(vertical: 8, horizontal: 8);
                          }).toList(),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Icon(Icons.lock_outline_rounded, size: 16, color: Colors.grey),
                            Text('${data.createdAt!.timeAgo}', style: secondaryTextStyle(size: 10)),
                          ],
                        ).paddingSymmetric(vertical: 8, horizontal: 8),
                      ],
                    ),
                  ),
                ),
                Container(
                  width: context.width(),
                  padding: EdgeInsets.all(16),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: colorPrimary,
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(defaultRadius),
                      bottomRight: Radius.circular(defaultRadius),
                    ),
                  ),
                  child: Text('view_detail'.translate, style: primaryTextStyle(color: Colors.white)),
                ).onTap(() {
                  ViewPollDetailScreen(model: data).launch(context);
                })
              ],
            ),
          );
        },
        shrinkWrap: true,
        // orderBy is compulsory to enable pagination
        query: audiencePollService.getPollListByUserID(getStringAsync(USER_ID)),
        itemsPerPage: PollLimit,
        bottomLoader: Loader(),
        initialLoader: Loader(),
        onEmpty: noDataWidget(),
        isLive: true,
        onError: (e) => Text(e.toString(), style: primaryTextStyle()).center(),
      ),
    );
  }
}
