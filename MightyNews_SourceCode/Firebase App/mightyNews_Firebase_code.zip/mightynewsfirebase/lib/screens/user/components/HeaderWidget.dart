import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';
import 'package:mighty_news_firebase/main.dart';
import 'package:mighty_news_firebase/utils/Constants.dart';
import 'package:nb_utils/nb_utils.dart';

import '../NotificationScreen.dart';

class HeaderWidget extends StatelessWidget {
  static String tag = '/';

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(boxShadow: defaultBoxShadow(shadowColor: Colors.transparent)),
      margin: EdgeInsets.only(top: 12, bottom: 12),
      child: Row(
        children: [
          8.width,
          Container(
            child: Image.asset('assets/app_logo.png', height: 40),
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(color: appStore.isDarkMode ? Colors.white : Colors.white, shape: BoxShape.circle),
          ),
          16.width,
          Text(mAppName, style: boldTextStyle(size: 22)).expand(),
          IconButton(
              onPressed: () {
                NotificationScreen().launch(context);
              },
              icon: Icon(Ionicons.md_notifications_outline)),
          8.width,
        ],
      ),
    );
  }
}
