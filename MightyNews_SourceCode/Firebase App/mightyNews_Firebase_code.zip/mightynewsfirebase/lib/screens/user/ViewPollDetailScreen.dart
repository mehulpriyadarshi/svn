import 'package:flutter/material.dart';
import 'package:mighty_news_firebase/components/AppWidgets.dart';
import 'package:mighty_news_firebase/models/AudiencePollModel.dart';
import 'package:mighty_news_firebase/services/PollAnswerListService.dart';
import 'package:mighty_news_firebase/utils/Colors.dart';
import 'package:mighty_news_firebase/utils/Common.dart';
import 'package:mighty_news_firebase/utils/Constants.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../main.dart';

class ViewPollDetailScreen extends StatefulWidget {
  static String tag = '/ViewPollDetailScreen';
  final AudiencePollModel? model;

  ViewPollDetailScreen({this.model});

  @override
  ViewPollDetailScreenState createState() => ViewPollDetailScreenState();
}

class ViewPollDetailScreenState extends State<ViewPollDetailScreen> {
  late PollAnswerListService pollAnswerService = PollAnswerListService(pollID: widget.model!.id);
  List<UserData> userDataList = [];

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    pollAnswerService.getAllPollAnswerList().listen((e) {
      userDataList.clear();
      userDataList.addAll(e);

      setState(() {});
    }).onError((error) {
      log(error.toString());
    });
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget('view_poll_detail'.translate, color: appStore.isDarkMode ? scaffoldSecondaryDark : Colors.white),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.model!.pollQuestion.validate(), style: boldTextStyle(size: 22)).paddingSymmetric(vertical: 16, horizontal: 8),
          Container(
            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 8),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: widget.model!.pollTagsList!.map((e) {
                return Text(e.validate(), style: primaryTextStyle(color: Colors.blue, size: 12));
              }).toList(),
            ),
          ),
          Divider(thickness: 1, height: 0),
          Container(
            width: context.width(),
            child: Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: context.cardColor,
                    boxShadow: [BoxShadow(color: appStore.isDarkMode ? Colors.white24 : Colors.grey.shade400, offset: Offset(12, 0), blurRadius: 20, spreadRadius: -5)],
                  ),
                  padding: EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                  child: Column(
                    children: [
                      Text('${userDataList.length.validate()}', style: boldTextStyle(size: 18)),
                      Text('Total votes', style: secondaryTextStyle()),
                    ],
                  ),
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: widget.model!.pollChoiceList!.map((e) {
                      return Container(
                        margin: EdgeInsets.symmetric(horizontal: 8),
                        child: Column(
                          children: [
                            Text('${answerCount(userDataList, e)}', style: boldTextStyle(size: 18)),
                            4.height,
                            createRichText(
                              list: [
                                TextSpan(text: '${'votes_for'.translate} ', style: secondaryTextStyle(size: 10)),
                                TextSpan(text: '${e.validate()}', style: boldTextStyle(size: 14)),
                              ],
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ).paddingSymmetric(vertical: 8),
                ).expand(),
              ],
            ),
          ),
          Divider(thickness: 1, height: 0),
          Text('voters'.translate, style: boldTextStyle(size: 20)).paddingSymmetric(vertical: 16, horizontal: 8),
          userDataList.isNotEmpty
              ? SingleChildScrollView(
                  child: Column(
                    children: userDataList.map((e) {
                      return Row(
                        children: [
                          cachedImage(e.pollUserImage.validate(), fit: BoxFit.cover, width: 40, height: 40).cornerRadiusWithClipRRect(60),
                          Text(e.pollUserName.validate(value: 'anonymous'.translate), style: primaryTextStyle(size: 18), overflow: TextOverflow.ellipsis).paddingAll(8).expand(),
                        ],
                      ).paddingAll(8);
                    }).toList(),
                  ),
                ).expand()
              : noDataWidget().center(),
        ],
      ),
      floatingActionButton: widget.model!.userId == getStringAsync(USER_ID)
          ? FloatingActionButton(
              onPressed: () {
                showConfirmDialogCustom(
                  context,
                  title: 'sure_delete_poll'.translate,
                  dialogType: DialogType.DELETE,
                  onAccept: (innerContext) async {
                    await pollAnswerService.deletePollAnswerList();

                    audiencePollService.removeDocument(widget.model!.id).then((value) {
                      finish(context);
                      toast('poll_delete_successfully'.translate);
                    }).catchError((error) {
                      toast(error.toString());
                    });
                  },
                );
              },
              backgroundColor: colorPrimary,
              child: Icon(Icons.delete_rounded),
            )
          : SizedBox(),
    );
  }

  int answerCount(List<UserData> list, String answer) {
    int count = 0;
    list.forEach((i) {
      if (i.pollAnswer == answer) {
        count++;
      }
    });
    return count;
  }
}
