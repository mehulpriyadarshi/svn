import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mighty_news_firebase/components/AppWidgets.dart';
import 'package:mighty_news_firebase/models/AudiencePollModel.dart';
import 'package:mighty_news_firebase/screens/user/components/AudiencePollItemWidget.dart';
import 'package:mighty_news_firebase/utils/Colors.dart';
import 'package:mighty_news_firebase/utils/Common.dart';
import 'package:mighty_news_firebase/utils/Constants.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:paginate_firestore/paginate_firestore.dart';

import '../../main.dart';

class ViewAllPollScreen extends StatefulWidget {
  static String tag = '/ViewAllPollScreen';

  @override
  ViewAllPollScreenState createState() => ViewAllPollScreenState();
}

class ViewAllPollScreenState extends State<ViewAllPollScreen> {
  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    //
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget('audience_polls'.translate, color: appStore.isDarkMode ? scaffoldSecondaryDark : Colors.white),
      body: PaginateFirestore(
        itemBuilderType: PaginateBuilderType.listView,
        itemBuilder: (context, documentSnapshot,index) {
          AudiencePollModel data = AudiencePollModel.fromJson(documentSnapshot[index].data() as Map<String, dynamic>);

          return AudiencePollItemWidget(model: data);
        },
        shrinkWrap: true,
        padding: EdgeInsets.all(8),
        // orderBy is compulsory to enable pagination
        query: audiencePollService.getAllAudiencePoll(),
        itemsPerPage: PollLimit,
        bottomLoader: Loader(),
        initialLoader: Loader(),
        onEmpty: noDataWidget(),
        onError: (e) => Text(e.toString(), style: primaryTextStyle()).center(),
      ),
    );
  }
}
