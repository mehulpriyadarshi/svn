import 'package:flutter/material.dart';
import 'package:mighty_news_firebase/models/AudiencePollModel.dart';
import 'package:mighty_news_firebase/utils/Colors.dart';
import 'package:mighty_news_firebase/utils/Common.dart';
import 'package:mighty_news_firebase/utils/Constants.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../main.dart';

class AddPollScreen extends StatefulWidget {
  static String tag = '/AddPollScreen';

  @override
  AddPollScreenState createState() => AddPollScreenState();
}

class AddPollScreenState extends State<AddPollScreen> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  List<String> pollTagList = [];
  List<String> item = [];
  List<String> pollChoiceList = [];

  TextEditingController pollQuestionController = TextEditingController();
  TextEditingController pollHashTagController = TextEditingController();
  List<TextEditingController> pollChoiceController = [];
  List<FocusNode> pollChoiceFocusNode = [];

  int choiceOptionLength = 4;
  int choiceItemLength = 1;
  bool isShowTagList = false;

  String pollDuration = '';

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    pollChoiceController = List.filled(choiceItemLength, TextEditingController(), growable: true);
    pollChoiceFocusNode = List.filled(choiceItemLength, FocusNode(), growable: true);

    item.clear();
    item.addAll(tagList);

    pollDuration = pollDurationList.first;
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    super.dispose();
  }

  void addPoll() async {
    hideKeyboard(context);

    if (formKey.currentState!.validate()) {
      formKey.currentState!.save();

      if (pollQuestionController.text.isNotEmpty) {
        if (pollChoiceController.length >= 2) {
          AudiencePollModel model = AudiencePollModel();

          model.pollQuestion = pollQuestionController.text.trim();
          model.pollChoiceList = pollChoiceController.map((e) => e.text.trim()).toList();
          model.userId = getStringAsync(USER_ID);
          model.pollDuration = pollDuration;
          model.pollTagsList = pollTagList;
          model.createdAt = DateTime.now();
          model.endAt = DateTime.now().add(Duration(hours: pollDuration.split(' ').first.toInt()));

          await audiencePollService.addDocument(model.toJson()).then((value) {
            pollQuestionController.clear();
            pollHashTagController.clear();
            pollChoiceController.forEach((e) {
              e.clear();
            });
            pollTagList.clear();

            toast('poll_add_successfully'.translate);

            LiveStream().emit(PollStreamRefresh, true);

            finish(context);
          }).catchError((error) {
            toast(error.toString());
          });
        } else {
          toast('add_more_then_one_poll_choice'.translate);
        }
      } else {
        toast('fill_all_necessary_details_poll'.translate);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: appBarWidget('add_audience_poll'.translate, color: appStore.isDarkMode ? scaffoldSecondaryDark : Colors.white),
      body: Form(
        key: formKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Container(
          width: context.width(),
          height: context.height(),
          child: Stack(
            children: [
              ScrollConfiguration(
                behavior: CustomBehavior(),
                child: SingleChildScrollView(
                  clipBehavior: Clip.none,
                  padding: EdgeInsets.only(bottom: 50),
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.all(16),
                        decoration: BoxDecoration(border: Border.all(color: Colors.grey), borderRadius: BorderRadius.circular(8)),
                        child: Column(
                          children: [
                            AppTextField(
                              controller: pollQuestionController,
                              textFieldType: TextFieldType.ADDRESS,
                              textStyle: boldTextStyle(size: 18),
                              errorThisFieldRequired: errorThisFieldRequired,
                              decoration: InputDecoration(
                                hintText: 'your_question'.translate,
                                hintStyle: primaryTextStyle(color: Colors.grey.shade500),
                                border: InputBorder.none,
                              ),
                            ).paddingAll(8),
                            Container(
                              width: context.width(),
                              padding: EdgeInsets.all(8),
                              child: Wrap(
                                alignment: WrapAlignment.start,
                                spacing: 8,
                                runSpacing: 8,
                                children: pollTagList.map((e) {
                                  return Text(e.validate(), style: primaryTextStyle(color: Colors.blue, size: 20)).onTap(() async {
                                    bool removeTag = await showConfirmDialog(context, 'Remove_this_hashtag'.translate);
                                    if (removeTag) {
                                      pollTagList.remove(e);
                                      setState(() {});
                                    }
                                  });
                                }).toList(),
                              ),
                            ),
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton(
                                  onPressed: () {
                                    hideKeyboard(context);
                                    isShowTagList = true;

                                    setState(() {});
                                  },
                                  child: Text('#' + 'tags'.translate, style: primaryTextStyle(color: Colors.blue, size: 22))),
                            ).paddingSymmetric(vertical: 4, horizontal: 8),
                            ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount: choiceItemLength,
                              itemBuilder: (context, index) {
                                return AppTextField(
                                  controller: pollChoiceController[index],
                                  maxLength: 25,
                                  textStyle: primaryTextStyle(),
                                  textInputAction: TextInputAction.done,
                                  decoration: InputDecoration(
                                    counterStyle: secondaryTextStyle(),
                                    labelText: '${'choice'.translate} ${index + 1}',
                                    labelStyle: secondaryTextStyle(),
                                    hintText: '${'choice'.translate} ${index + 1}',
                                    hintStyle: secondaryTextStyle(),
                                    border: OutlineInputBorder(),
                                    focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey.shade500)),
                                    focusedErrorBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey.shade500)),
                                    errorBorder: OutlineInputBorder(borderSide: BorderSide(color: colorPrimary)),
                                    enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey.shade500)),
                                    alignLabelWithHint: true,
                                    suffixIcon: index >= 2
                                        ? Icon(Icons.close, color: appStore.isDarkMode ? Colors.grey.shade500 : Colors.black.withOpacity(0.7)).onTap(() {
                                            choiceItemLength -= 1;
                                            pollChoiceController.removeAt(index);
                                            pollChoiceFocusNode.removeAt(index);
                                            setState(() {});
                                          })
                                        : null,
                                  ),
                                  textFieldType: TextFieldType.NAME,
                                  errorThisFieldRequired: errorThisFieldRequired,
                                ).paddingAll(8);
                              },
                            ),
                            choiceItemLength < choiceOptionLength
                                ? MaterialButton(
                                    onPressed: () {
                                      choiceItemLength += 1;
                                      pollChoiceController.add(TextEditingController());

                                      setState(() {});

                                      context.requestFocus(pollChoiceFocusNode.last);
                                    },
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.add, color: appStore.isDarkMode ? Colors.grey.shade500 : Colors.black.withOpacity(0.7)),
                                        Text('click_to_add_choice'.translate, style: primaryTextStyle(color: appStore.isDarkMode ? Colors.grey.shade500 : Colors.black.withOpacity(0.7), size: 18)),
                                      ],
                                    ),
                                  ).paddingAll(8)
                                : SizedBox(),
                            Divider(color: appStore.isDarkMode ? Colors.white : Colors.black, thickness: 0.2),
                            Row(
                              children: [
                                Text('${'poll_duration'.translate} : ', style: primaryTextStyle()),
                                DropdownButton<String>(
                                  value: pollDuration,
                                  dropdownColor: appStore.isDarkMode ? scaffoldSecondaryDark : Colors.white,
                                  style: primaryTextStyle(),
                                  underline: Container(
                                    height: 2,
                                  ),
                                  onChanged: (String? newValue) {
                                    setState(() {
                                      pollDuration = newValue!;
                                    });
                                  },
                                  items: pollDurationList.map<DropdownMenuItem<String>>((String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                )
                              ],
                            ).paddingSymmetric(horizontal: 8)
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                child: Container(
                  color: colorPrimary,
                  width: context.width(),
                  padding: EdgeInsets.symmetric(vertical: 18),
                  child: Text(
                    'add_poll'.translate,
                    style: primaryTextStyle(color: Colors.white, size: 18),
                    textAlign: TextAlign.center,
                  ),
                ).onTap(() {
                  addPoll();
                }),
              ),
              if (isShowTagList) showTagList(context, tagList),
            ],
          ),
        ),
      ),
    );
  }

  Widget showTagList(BuildContext context, List<String> tagList) {
    return Container(
      width: context.width(),
      height: context.height(),
      color: appStore.isDarkMode ? scaffoldSecondaryDark : Colors.white,
      padding: EdgeInsets.all(8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Align(
            alignment: Alignment.centerRight,
            child: IconButton(
              onPressed: () {
                isShowTagList = false;
                pollHashTagController.clear();

                setState(() {});
              },
              icon: Icon(Icons.close),
            ),
          ),
          AppTextField(
            controller: pollHashTagController,
            textFieldType: TextFieldType.NAME,
            textStyle: primaryTextStyle(size: 18, color: Colors.blue),
            decoration: InputDecoration(
              hintText: 'search_hashtag'.translate,
              hintStyle: primaryTextStyle(color: Colors.grey.shade500),
              focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey.shade500)),
              focusedErrorBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey.shade500)),
              errorBorder: OutlineInputBorder(borderSide: BorderSide(color: colorPrimary)),
              enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey.shade500)),
            ),
            onChanged: (val) {
              if (val.startsWith('#')) {
                item = filterSearchResults(val, tagList);
                setState(() {});
              }
            },
          ),
          pollHashTagController.text.trim().startsWith('#')
              ? item.isNotEmpty
                  ? ScrollConfiguration(
                      behavior: CustomBehavior(),
                      child: SingleChildScrollView(
                        child: Container(
                          width: context.width(),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: item.map((e) {
                              return Text(
                                e.validate(),
                                style: primaryTextStyle(color: Colors.blue, size: 20),
                              ).paddingSymmetric(vertical: 12).onTap(() {
                                pollTagList.add(e);
                                isShowTagList = false;
                                pollHashTagController.clear();

                                setState(() {});
                              });
                            }).toList(),
                          ),
                        ),
                      ).expand(),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${pollHashTagController.text.trim()}', style: primaryTextStyle(color: Colors.blue, size: 20)),
                        4.height,
                        Text('create_new_hashtag'.translate, style: secondaryTextStyle()),
                      ],
                    ).paddingSymmetric(vertical: 12).onTap(() {
                      pollTagList.add(pollHashTagController.text.trim());
                      isShowTagList = false;
                      pollHashTagController.clear();

                      setState(() {});
                    })
              : Text('choose_or_add_your_tag'.translate, style: secondaryTextStyle()).paddingAll(8),
        ],
      ),
    );
  }
}
