import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';
import 'package:intl/intl.dart';
import 'package:mighty_news_firebase/screens/user/NewsDetailScreen.dart';
import 'package:mighty_news_firebase/utils/Common.dart';
import 'package:nb_utils/nb_utils.dart';
import '../../AppLocalizations.dart';
import '../../components/AppWidgets.dart';
import '../../main.dart';
import '../../models/NotificationModel.dart';
import '../../utils/Colors.dart';

class NotificationScreen extends StatefulWidget {
  @override
  NotificationScreenState createState() => NotificationScreenState();
}

class NotificationScreenState extends State<NotificationScreen> {
  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {}

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget("notification".translate, color: appStore.isDarkMode ? scaffoldSecondaryDark : Colors.white, showBack: true),
      body: FutureBuilder<List<NotificationClass>>(
        future: notificationService.getNotification(),
        builder: (_, snap) {
          if (snap.hasData) {
            if (snap.data != null && snap.data!.isNotEmpty)
              return ListView.separated(
                itemCount: snap.data!.length,
                separatorBuilder: (BuildContext context, int index) {
                  return Divider(height: 0, thickness: 1);
                },
                itemBuilder: (context, index) {
                  NotificationClass data = snap.data![index];
                  return Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        data.img != null && data.img!.isNotEmpty
                            ? cachedImage(data.img.validate(), height: 40, width: 40, fit: BoxFit.cover).cornerRadiusWithClipRRect(4)
                            : Container(
                                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                                decoration: boxDecorationWithRoundedCorners(borderRadius: radius(8), backgroundColor: colorPrimary.withOpacity(0.1)),
                                child: Icon(Feather.bell),
                              ),
                        12.width,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(data.title.validate(), style: boldTextStyle()).expand(),
                                Text(DateFormat("dd MMM hh:mm a").format(data.createdAt!), style: secondaryTextStyle()),
                              ],
                            ),
                            8.height,
                            Text('${data.dec.toString().replaceAll('_', ' ').capitalizeFirstLetter().validate()}', style: secondaryTextStyle()),
                            8.height,
                          ],
                        ).expand(),
                      ],
                    ).paddingSymmetric(vertical: 8).onTap(() {
                      log("NewsId" + data.newsId.toString());
                      if (data.newsId != null && data.newsId!.isNotEmpty) NewsDetailScreen(id: data.newsId).launch(context);
                      // BookingDetailScreen(bookingId: data.data!.id.validate()).launch(context, pageRouteAnimation: PageRouteAnimation.Slide);
                    }),
                  );
                },
              );
            else
              return noDataWidget();
          } else {
            return snapWidgetHelper(snap);
          }
        },
      ),
    );
  }
}
