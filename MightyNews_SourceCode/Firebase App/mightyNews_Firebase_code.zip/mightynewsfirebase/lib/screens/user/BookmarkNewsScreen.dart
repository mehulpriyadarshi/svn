import 'package:flutter/material.dart';
import 'package:mighty_news_firebase/components/AppWidgets.dart';
import 'package:mighty_news_firebase/models/NewsData.dart';
import 'package:mighty_news_firebase/utils/Colors.dart';
import 'package:mighty_news_firebase/utils/Common.dart';
import 'package:mighty_news_firebase/utils/Constants.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../main.dart';
import 'UserNewsListWidget.dart';

class BookmarkNewsScreen extends StatefulWidget {
  final bool? isBookMark;

  BookmarkNewsScreen(this.isBookMark);

  static String tag = '/BookmarkNewsScreen';

  @override
  _BookmarkNewsScreenState createState() => _BookmarkNewsScreenState();
}

class _BookmarkNewsScreenState extends State<BookmarkNewsScreen> with AutomaticKeepAliveClientMixin {
  List<NewsData> data = [];

  @override
  void initState() {
    super.initState();
    init();
  }

  @override
  bool get wantKeepAlive => true;

  Future<void> init() async {
    loadBookMarkNews();
  }

  loadBookMarkNews() {
    LiveStream().on(StreamRefreshBookmark, (s) {
      setState(() {});
    });
    appStore.setLoading(true);
    data.clear();
    newsService.getBookmarkNewsFuture().then((value) {
      value.forEachIndexed((e, index) {
        bookmarkList.forEachIndexed((e1, i) {
          if (e1!.contains(e.id.toString())) {
            data.add(e);
            appStore.setLoading(false);
            setState(() {});
            log(data.length.toString());
          }
        });
      });
    });
  }

  @override
  void dispose() {
    LiveStream().dispose(StreamRefreshBookmark);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return Scaffold(
        appBar: appBarWidget('bookmarks'.translate, color: appStore.isDarkMode ? scaffoldSecondaryDark : Colors.white, showBack: false),
        body: Stack(
          children: [
            SingleChildScrollView(
                physics: BouncingScrollPhysics(),
                child: UserNewsListWidget(
                  list: data,
                  onTap: () {
                    init();
                    setState(() {});
                  },
                )),
            if (data == null && data.isEmpty) noDataWidget(),
            if (appStore.isLoading) Loader().center()
          ],
        )

      // FutureBuilder<List<NewsData>>(
      //   future: newsService.getBookmarkNewsFuture(),
      //   builder: (_, snap) {
      //     if (snap.hasData) {
      //       if (snap.data!.isEmpty) return noDataWidget();
      //
      //       return SingleChildScrollView(
      //         physics: BouncingScrollPhysics(),
      //         child:
      //       );
      //     } else {
      //       return snapWidgetHelper(snap);
      //     }
      //   },
      // ),
    );
  }
}
